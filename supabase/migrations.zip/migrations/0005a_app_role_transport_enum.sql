alter type public.app_role add value if not exists 'transport';
